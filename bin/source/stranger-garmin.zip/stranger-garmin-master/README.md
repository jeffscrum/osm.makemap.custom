stranger-garmin
===============

Стиль карт для Garmin сайта velo100.ru


Based on mkgmap source code
License: GPLv2
